package com.example.casio;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private TextView input, output;
    private boolean firstNumber = false, secondNumber = false, methodCalc = false;
    private String method = "";
    private double numberOne = 0, numberTwo = 0;
    private String strNumberOne = "", strSecondNumber = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        anhXa();
    }

    public void setView() {
        input.setText(strNumberOne + " " + method + " " + strSecondNumber);
    }

    public void checkNumber(int a) {
        if (!firstNumber && !methodCalc) {
            strNumberOne += a;
            numberOne = Double.parseDouble(strNumberOne);
            firstNumber = true;
        } else if (firstNumber && !methodCalc) {
            strNumberOne += a;
            numberOne = Double.parseDouble(strNumberOne);
        } else if (firstNumber && methodCalc && !secondNumber) {
            strSecondNumber += a;
            numberTwo = Double.parseDouble(strSecondNumber);
            secondNumber = true;
        } else if (firstNumber && methodCalc && secondNumber) {
            strSecondNumber += a;
            numberTwo = Double.parseDouble(strSecondNumber);
        }
    }

    public double calculate() {
        double result = 0;
        if (method.equals("+")) {
            result = numberOne + numberTwo;
        } else if (method.equals("-")) {
            result = numberOne - numberTwo;
        } else if (method.equals("*")) {
            result = numberOne * numberTwo;
        } else if (method.equals("/")) {
            if (numberTwo != 0) {
                result = numberOne / numberTwo;
            }
        }
        return result;
    }

    public void anhXa() {
        input = findViewById(R.id.input);
        output = findViewById(R.id.output);
    }

    public void btnC(View view) {
        input.setText("");
        output.setText("");
        firstNumber = false;
        secondNumber = false;
        methodCalc = false;
        numberOne = 0;
        numberTwo = 0;
        strNumberOne = "";
        strSecondNumber = "";
        method = "";
    }

    public void btnChia(View view) {
        method = "/";
        methodCalc = true;
        setView();
    }

    public void btn7(View view) {
        checkNumber(7);
        setView();
    }

    public void btn8(View view) {
        checkNumber(8);
        setView();
    }

    public void btn9(View view) {
        checkNumber(9);
        setView();
    }

    public void btnNhan(View view) {
        method = "*";
        methodCalc = true;
        setView();
    }

    public void btn4(View view) {
        checkNumber(4);
        setView();
    }

    public void btn5(View view) {
        checkNumber(5);
        setView();
    }

    public void btn6(View view) {
        checkNumber(6);
        setView();
    }

    public void btnTru(View view) {
        method = "-";
        methodCalc = true;
        setView();
    }

    public void btn1(View view) {
        checkNumber(1);
        setView();
    }

    public void btn2(View view) {
        checkNumber(2);
        setView();
    }

    public void btn3(View view) {
        checkNumber(3);
        setView();
    }

    public void btnCong(View view) {
        method = "+";
        methodCalc = true;
        setView();
    }

    public void btn0(View view) {
        checkNumber(0);
        setView();
    }

    public void btnDot(View view) {
        if (!firstNumber && !methodCalc && !strNumberOne.contains(".")) {
            strNumberOne += ".";
            setView();
        } else if (firstNumber && methodCalc && !secondNumber && !strSecondNumber.contains(".")) {
            strSecondNumber += ".";
            setView();
        } else if (firstNumber && !methodCalc && !strNumberOne.contains(".")) {
            strNumberOne+= ".";
            setView();
        } else if (firstNumber && methodCalc && secondNumber && !strSecondNumber.contains(".")) {
            strSecondNumber += ".";
            setView();
        }
    }

    public void btnCalc(View view) {
        if (firstNumber && secondNumber && methodCalc) {
            double result = calculate();
            output.setText(String.valueOf(result));
            strNumberOne = String.valueOf(result);
            strSecondNumber = "";
            numberOne = result;
            numberTwo = 0;
            secondNumber = false;
            methodCalc = false;
        }
    }
}